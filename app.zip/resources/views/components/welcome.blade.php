<div class="bg-gray-200 bg-opacity-25  gap-6 lg:gap-8 p-6 lg:p-8 flex items-center justify-center text-center h-full">
  <div class="flex flex-col items-center justify-center ml-5">
        @include('games.pong')
    </div>
</div>   

