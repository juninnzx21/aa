<header class="fixed top-0 left-0 w-full bg-gray-800 z-50 text-sm mb-6">
    <div id="fixed-header">
        <div id="header" class="flex justify-between items-center px-4 py-2">

                        <!-- Botão para abrir/fechar o menu -->
                <button id="toggleSidebar" class="p-2"  style=" background-colo: #000;">                               
                    <img src="/imgs/navbar.png"  style="width: 40px; height: 20px; color:#000; background-colo: #000;" alt="Menu">
                </button>
                <!-- ESQUERDA -->
                <div class="flex items-center gap-4">
                    <div class="left-bar-action">
                            <a href="/">
                                <img alt="menu" style="width: 50%; height: 50%;" src="/imgs/aa.png">
                            </a>
                    </div>
                </div>

                <!-- DIREITA -->
                @if (Route::has('login'))
                    <div class="flex items-center gap-2">
                        @auth
                            <a href="{{ url('/dashboard') }}" class="text-sm px-4 py-1 border rounded border-gray-300 dark:border-[#3E3E3A] text-[#1b1b18] dark:text-[#EDEDEC] hover:border-gray-500">
                                Dashboard
                            </a>
                        @else
                            <a href="{{ route('login') }}" class="text-sm text-[#1b1b18] dark:text-[#EDEDEC]">
                                Entrar
                            </a>
                            @if (Route::has('register'))
                                <a href="{{ route('register') }}">
                                    <button class="text-sm px-4 py-1 rounded bg-[#f12c4c] text-white">
                                        Cadastre-se
                                    </button>
                                </a>
                            @endif
                        @endauth
                    </div>
                @endif
            </div>
        </div>           
        <aside id="leftbar" class="fixed top-20 left-0 h-full w-64 bg-gray-800    shadow-lg transform -translate-x-full transition-transform duration-300 z-50">
            <div class="p-4 flex justify-between items-center border-b border-gray-200 dark:border-[#3E3E3A]">
                <a href="" id="logo">
                    <img class="main" src="/imgs/aa.png" alt="Logo">
                </a>
                <button id="closeSidebar">
                
                </button>
            </div>
            <nav class="p-4 overflow-y-auto h-[calc(100%-60px)]">
                <ul class="space-y-3">
                    <a href="games/pong" class="block px-4 py-2 colr-blue hover:bg-gray-500">
                       💣 Jogo: Pong
                    </a>
                </ul>
            </nav>
        </aside>         
 </header>